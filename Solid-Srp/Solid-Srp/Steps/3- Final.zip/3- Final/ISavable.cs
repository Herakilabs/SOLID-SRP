﻿namespace Solid_Srp
{
    public interface ISavable
    {
    }
}
